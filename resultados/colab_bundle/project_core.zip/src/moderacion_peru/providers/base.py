from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from ..schemas import AnnotationRecord, LLMAnnotationPayload
from ..taxonomy import TaxonomyContract, load_taxonomy


class ProviderError(RuntimeError):
    pass


SYSTEM_PROMPT = """Eres un anotador de fragmentos de subtítulos peruanos. Aplica exclusivamente el contrato entregado. Las únicas salidas gruesas son SEGURO, RACISMO_DISCRIMINACION, ATAQUE_POR_GENERO_IDENTIDAD, ACOSO_AMENAZA y CONTENIDO_SEXUAL. SEGURO es una categoría explícita y nunca puede coexistir con daño. RACISMO_DISCRIMINACION, ATAQUE_POR_GENERO_IDENTIDAD, ACOSO_AMENAZA y CONTENIDO_SEXUAL pueden coexistir. Las etiquetas gruesas deben coincidir exactamente con las derivadas de las etiquetas finas. SEGURO exige `seguro` o `seguro_ironia_marcada` como estado fino. Siempre debes emitir por lo menos una etiqueta fina y una gruesa: si hay duda, elige la hipótesis mejor respaldada, reduce `score_confianza`, activa `needs_review` y usa los flags aplicables; nunca respondas con listas de etiquetas vacías. `score_confianza` estima la corrección del conjunto completo de etiquetas, no la intensidad del daño: por debajo de 0.85 requiere revisión y con `contexto_necesario` o `ironia_ambigua` no puede superar 0.65. Distingue discurso citado, condenado, informativo o ficticio del ataque respaldado por el hablante. Conserva exactamente el chunk_id recibido y devuelve únicamente JSON conforme al esquema, sin razonamiento ni texto adicional."""

SELF_REVIEW_CONFIDENCE_THRESHOLD = 0.85


def taxonomy_prompt(taxonomy: TaxonomyContract) -> str:
    blocks = []
    for label in taxonomy.target_labels:
        category = taxonomy.categories[label]
        blocks.append(
            f"{label}: {category.definition}\n"
            f"Incluye: {'; '.join(category.include)}.\n"
            f"Excluye: {'; '.join(category.exclude)}.\n"
            f"Etiquetas finas: {', '.join(category.fine_labels)}."
        )
    return "\n\n".join(blocks)


def normalize_payload(
    payload: dict[str, Any],
    *,
    text: str,
    source: str,
    annotator_type: str,
    model: str,
    video_id: str | None = None,
    chunk_metadata: dict[str, Any] | None = None,
    source_record_sha256: str | None = None,
    prompt_sha256: str | None = None,
    taxonomy: TaxonomyContract | None = None,
) -> AnnotationRecord:
    contract = taxonomy or load_taxonomy()
    parsed = LLMAnnotationPayload.model_validate(payload)
    fine = contract.normalize_fine_labels(parsed.fine_labels)
    coarse = contract.normalize_categories(parsed.coarse_labels)
    if coarse == (contract.safe_label,) and not set(fine).intersection(
        contract.categories[contract.safe_label].fine_labels
    ):
        raise ProviderError("SEGURO requiere un estado fino seguro explícito")
    if not fine or not coarse:
        raise ProviderError(
            f"La respuesta LLM para {parsed.chunk_id} debe incluir su mejor etiqueta fina y gruesa"
        )
    if fine:
        derived = contract.derive_categories(fine)
        if coarse != derived:
            raise ProviderError(
                f"Inconsistencia fina→gruesa para {parsed.chunk_id}: {fine} -> {derived}, recibió {coarse}"
            )
    needs_review = (
        parsed.needs_review
        or bool(parsed.flags)
        or parsed.score_confianza < SELF_REVIEW_CONFIDENCE_THRESHOLD
    )
    metadata = chunk_metadata or {}
    return AnnotationRecord(
        chunk_id=parsed.chunk_id,
        video_id=video_id,
        start_seconds=metadata.get("start_seconds"),
        end_seconds=metadata.get("end_seconds"),
        video_title=metadata.get("video_title") or metadata.get("title"),
        channel_title=metadata.get("channel_title") or metadata.get("channel"),
        source_url=metadata.get("source_url") or metadata.get("url"),
        cohort=metadata.get("cohort"),
        text=text,
        coarse_labels=list(coarse),
        fine_labels=list(fine),
        flags=list(dict.fromkeys(parsed.flags)),
        needs_review=needs_review,
        training_eligible=not needs_review,
        decision_status="needs_review" if needs_review else "resolved",
        score_confianza=parsed.score_confianza,
        notes=parsed.notes,
        justification=parsed.justificacion,
        label_source=source,
        annotator_type=annotator_type,  # type: ignore[arg-type]
        annotator_model=model,
        prompt_sha256=prompt_sha256,
        source_record_sha256=source_record_sha256,
    )


class AnnotationProvider(ABC):
    def __init__(self, model: str, taxonomy: TaxonomyContract | None = None) -> None:
        self.model = model
        self.taxonomy = taxonomy or load_taxonomy()

    @abstractmethod
    def probe(self) -> dict[str, Any]:
        raise NotImplementedError

    @abstractmethod
    def annotate(self, chunk: dict[str, Any]) -> AnnotationRecord:
        raise NotImplementedError

    def annotate_batch(
        self, chunks: list[dict[str, Any]]
    ) -> list[AnnotationRecord | Exception]:
        """Anota un lote y conserva un resultado independiente por entrada.

        Los proveedores sin soporte vectorizado mantienen el comportamiento
        correcto mediante este fallback. Los backends GPU pueden sobrescribirlo
        para explotar batching real sin abrir hilos que compitan por la GPU.
        """

        results: list[AnnotationRecord | Exception] = []
        for chunk in chunks:
            try:
                results.append(self.annotate(chunk))
            except (ProviderError, ValueError, RuntimeError) as exc:
                results.append(exc)
        return results
