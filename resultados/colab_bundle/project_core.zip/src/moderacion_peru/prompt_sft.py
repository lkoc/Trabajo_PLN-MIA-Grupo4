from __future__ import annotations

import hashlib
import json
import re
import time
from collections.abc import Sequence
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import numpy as np

from .device import (
    cuda_performance_profile,
    high_memory_bf16_cuda,
    resolve_device,
    torch_device_name,
)
from .experiments import (
    TRAINING_ENGINE_VERSION,
    ProgressCallback,
    _checkpoint_manifest,
    _dataset_splits,
    _evaluate_validation,
    _experiment_signature,
    _notify_progress,
    _require_project_safe_ratio,
)
from .io import sha256_file, write_json_atomic
from .persistent_checkpoints import (
    build_persistent_checkpoint_callback,
    restore_latest_trainer_checkpoint,
)
from .taxonomy import load_taxonomy

PROMPT_SFT_MODEL_ID = "Qwen/Qwen3-0.6B"
PROMPT_SFT_MODEL_REVISION = "6130ef31402718485ca4d80a6234f70d9a4cf362"
PROMPT_SFT_GRADIENT_CHECKPOINTING = "non_reentrant_input_grad_v1"
PROMPT_SFT_TRAINING_REGIMES = {
    "full",
    "diagnostic_pilot",
    "budgeted_comparable",
}


def _configure_lora_gradient_checkpointing(
    model: Any, *, enabled: bool = True
) -> dict[str, Any]:
    """Conserva el grafo LoRA cuando el backbone causal está congelado.

    El checkpointing reentrante de PyTorch exige que al menos una entrada tenga
    ``requires_grad=True``. En PEFT las entradas y el backbone están congelados,
    aunque los adaptadores sí sean entrenables, y la pérdida puede quedar sin
    ``grad_fn``. Se habilitan gradientes de entrada y se solicita la variante no
    reentrante, recomendada por Transformers para este caso.
    """

    trainable = [
        (name, parameter)
        for name, parameter in model.named_parameters()
        if parameter.requires_grad
    ]
    if not trainable:
        raise RuntimeError(
            "Qwen SFT no tiene parámetros entrenables después de insertar LoRA"
        )
    non_lora = [name for name, _parameter in trainable if "lora_" not in name]
    if non_lora:
        raise RuntimeError(
            "Qwen SFT esperaba entrenar solo adaptadores LoRA; parámetros inesperados: "
            + ", ".join(non_lora[:5])
        )

    if not enabled:
        return {
            "policy": "disabled_for_short_sequence_budget_profile",
            "trainable_parameter_tensors": len(trainable),
            "trainable_parameters": int(
                sum(parameter.numel() for _name, parameter in trainable)
            ),
            "input_gradient_method": None,
            "checkpointing_mode": "disabled",
        }

    input_gradient_method = "enable_input_require_grads"
    if hasattr(model, "enable_input_require_grads"):
        model.enable_input_require_grads()
    else:
        embeddings = model.get_input_embeddings()

        def require_output_grad(_module: Any, _inputs: Any, output: Any) -> None:
            output.requires_grad_(True)

        embeddings.register_forward_hook(require_output_grad)
        input_gradient_method = "embedding_forward_hook"

    try:
        model.gradient_checkpointing_enable(
            gradient_checkpointing_kwargs={"use_reentrant": False}
        )
        checkpointing_mode = "non_reentrant"
    except TypeError:
        # Compatibilidad defensiva con Transformers antiguos. La entrada con
        # gradiente evita igualmente que el checkpoint reentrante corte el grafo.
        model.gradient_checkpointing_enable()
        checkpointing_mode = "legacy_reentrant_with_input_grad"

    return {
        "policy": PROMPT_SFT_GRADIENT_CHECKPOINTING,
        "trainable_parameter_tensors": len(trainable),
        "trainable_parameters": int(
            sum(parameter.numel() for _name, parameter in trainable)
        ),
        "input_gradient_method": input_gradient_method,
        "checkpointing_mode": checkpointing_mode,
    }


def _prompt_section(prompt: str, heading: str) -> str:
    selected: list[str] = []
    active = False
    for line in prompt.splitlines():
        if line.startswith("## "):
            if active:
                break
            active = line.strip() == heading
        if active:
            selected.append(line)
    return "\n".join(selected).strip()


def compile_operational_prompt_capsule(prompt: str, *, max_chars: int = 6200) -> str:
    """Compila v3.2 conservando contrato, jerarquía, categorías y JSON.

    La procedencia se prueba con el SHA del archivo completo. La cápsula evita
    repetir unas 6k fichas léxicas en cada ejemplo SFT, algo innecesariamente
    costoso; no crea criterios nuevos ni sustituye el prompt fuente.
    """

    preamble = "\n".join(
        line
        for line in prompt.splitlines()
        if line.startswith(("Versión del prompt", "Contrato y taxonomía"))
    )
    task = _prompt_section(prompt, "## Tarea y salidas permitidas")
    principle = _prompt_section(
        prompt, "## Principio rector: clasificar el evento de habla, no la palabra"
    )
    hierarchy = _prompt_section(prompt, "## Jerarquía obligatoria de decisión")
    consistency = _prompt_section(prompt, "## Consistencia obligatoria")
    response_format = _prompt_section(prompt, "## Formato de respuesta")
    fixed = "\n\n".join(
        part for part in (preamble, task, principle, consistency, response_format) if part
    )
    hierarchy_budget = max(0, max_chars - len(fixed) - 2)
    if len(hierarchy) > hierarchy_budget:
        trace = "\n[Jerarquía abreviada; el SHA identifica el prompt v3.2 completo.]"
        hierarchy = hierarchy[: max(0, hierarchy_budget - len(trace))].rsplit(
            "\n", 1
        )[0]
        hierarchy += trace
    capsule = "\n\n".join(
        part
        for part in (preamble, task, principle, hierarchy, consistency, response_format)
        if part
    ).strip()
    if not task or not principle or not hierarchy or not consistency or not response_format:
        raise ValueError("El prompt operacional no contiene las secciones obligatorias")
    return capsule


def _json_target(row: dict[str, Any]) -> str:
    return json.dumps(
        {
            "chunk_id": row["chunk_id"],
            "coarse_labels": row["coarse_labels"],
            "fine_labels": row.get("fine_labels", []),
            "flags": row.get("flags_reference_only", []),
            "score_confianza": 1.0,
            "needs_review": False,
            "justification": "decisión supervisada del snapshot",
        },
        ensure_ascii=False,
        separators=(",", ":"),
    )


def _mask_json_field(
    labels: list[int], offsets: Sequence[tuple[int, int]], text: str, field: str
) -> None:
    marker = f'"{field}":'
    start = text.find(marker)
    if start < 0:
        return
    value_start = start + len(marker)
    value_end = text.find("]", value_start) + 1
    for index, (left, right) in enumerate(offsets):
        if right > value_start and left < value_end:
            labels[index] = -100


class PromptCompletionDataset:
    def __init__(
        self,
        tokenizer: Any,
        rows: Sequence[dict[str, Any]],
        system_prompt: str,
        *,
        max_length: int,
    ) -> None:
        self.tokenizer = tokenizer
        self.rows = list(rows)
        self.system_prompt = system_prompt
        self.max_length = max_length

    def __len__(self) -> int:
        return len(self.rows)

    def __getitem__(self, index: int) -> dict[str, Any]:
        import torch

        taxonomy = load_taxonomy()
        row = self.rows[index]
        prompt = self.tokenizer.apply_chat_template(
            [
                {"role": "system", "content": self.system_prompt},
                {
                    "role": "user",
                    "content": _user_message(row),
                },
            ],
            tokenize=False,
            add_generation_prompt=True,
            enable_thinking=False,
        )
        target = _json_target(row) + (self.tokenizer.eos_token or "")
        prompt_ids = self.tokenizer(prompt, add_special_tokens=False)["input_ids"]
        target_encoding = self.tokenizer(
            target, add_special_tokens=False, return_offsets_mapping=True
        )
        target_ids = target_encoding["input_ids"]
        target_labels = list(target_ids)
        if not all(row.get("fine_observed_mask", [0] * len(taxonomy.fine_labels))):
            _mask_json_field(
                target_labels, target_encoding["offset_mapping"], target, "fine_labels"
            )
        if not all(row.get("flags_observed_mask", [0] * len(taxonomy.flags))):
            _mask_json_field(
                target_labels, target_encoding["offset_mapping"], target, "flags"
            )
        overflow = max(0, len(prompt_ids) + len(target_ids) - self.max_length)
        prompt_ids = prompt_ids[overflow:]
        input_ids = prompt_ids + target_ids
        labels = [-100] * len(prompt_ids) + target_labels
        attention = [1] * len(input_ids)
        padding = self.max_length - len(input_ids)
        input_ids += [self.tokenizer.pad_token_id] * padding
        attention += [0] * padding
        labels += [-100] * padding
        return {
            "input_ids": torch.tensor(input_ids),
            "attention_mask": torch.tensor(attention),
            "labels": torch.tensor(labels),
        }


def _user_message(row: dict[str, Any]) -> str:
    return (
        "Clasifica este chunk y devuelve solo JSON. "
        f"Copia chunk_id exactamente: {row['chunk_id']}\nTexto:\n{row['text']}"
    )


def _generate_json_scores(
    model: Any,
    tokenizer: Any,
    rows: Sequence[dict[str, Any]],
    system_prompt: str,
    *,
    device: str,
    max_input_length: int,
    batch_size: int = 1,
    max_new_tokens: int = 192,
    deadline_monotonic: float | None = None,
    progress_callback: ProgressCallback | None = None,
) -> tuple[np.ndarray, dict[str, Any]]:
    import torch

    taxonomy = load_taxonomy()
    output_labels = [*taxonomy.target_labels, *taxonomy.fine_labels, *taxonomy.flags]
    scores = np.zeros((len(rows), len(output_labels)), dtype=float)
    valid = 0
    schema_errors: dict[str, int] = {}
    model.eval()
    _notify_progress(
        progress_callback,
        status="started",
        phase="generando validation",
        total=len(rows),
        advance=0,
    )
    previous_padding_side = getattr(tokenizer, "padding_side", "right")
    tokenizer.padding_side = "left"
    try:
        for start in range(0, len(rows), batch_size):
            if (
                deadline_monotonic is not None
                and time.perf_counter() >= deadline_monotonic
            ):
                raise TimeoutError(
                    "El presupuesto total venció antes de completar validation. "
                    "No se escribió candidate.json y esta corrida todavía no puede entrar a 03_07."
                )
            batch_rows = rows[start : start + batch_size]
            prompts = [
                tokenizer.apply_chat_template(
                    [
                        {"role": "system", "content": system_prompt},
                        {
                            "role": "user",
                            "content": _user_message(row),
                        },
                    ],
                    tokenize=False,
                    add_generation_prompt=True,
                    enable_thinking=False,
                )
                for row in batch_rows
            ]
            encoded = tokenizer(
                prompts,
                return_tensors="pt",
                truncation=True,
                padding=True,
                max_length=max_input_length,
            )
            encoded = {
                key: value.to(device, non_blocking=device != "cpu")
                for key, value in encoded.items()
            }
            with torch.no_grad():
                generated = model.generate(
                    **encoded,
                    max_new_tokens=max_new_tokens,
                    do_sample=False,
                    pad_token_id=tokenizer.pad_token_id,
                    eos_token_id=tokenizer.eos_token_id,
                )
            texts = tokenizer.batch_decode(
                generated[:, encoded["input_ids"].shape[1] :],
                skip_special_tokens=True,
            )
            for offset, text in enumerate(texts):
                index = start + offset
                match = re.search(r"\{.*\}", text, flags=re.DOTALL)
                try:
                    payload = json.loads(match.group(0) if match else text)
                    coarse = taxonomy.normalize_categories(
                        payload.get("coarse_labels", ())
                    )
                    fine = taxonomy.normalize_fine_labels(
                        payload.get("fine_labels", ())
                    )
                    flags = tuple(
                        flag
                        for flag in payload.get("flags", ())
                        if flag in taxonomy.flags
                    )
                    returned_chunk_id = payload.get("chunk_id")
                    if returned_chunk_id != batch_rows[offset]["chunk_id"]:
                        raise ValueError("chunk_id no coincide")
                    confidence = float(
                        np.clip(
                            payload.get(
                                "score_confianza", payload.get("confidence", 0.5)
                            ),
                            0.0,
                            1.0,
                        )
                    )
                    if not coarse:
                        raise ValueError("coarse_labels vacío")
                    selected = set(coarse) | set(fine) | set(flags)
                    scores[index] = [
                        confidence if label in selected else 1 - confidence
                        for label in output_labels
                    ]
                    valid += 1
                except (ValueError, TypeError, json.JSONDecodeError) as exc:
                    key = type(exc).__name__
                    schema_errors[key] = schema_errors.get(key, 0) + 1
            _notify_progress(
                progress_callback,
                status="progress",
                phase="generando validation",
                advance=len(batch_rows),
                details={"JSON válidos": valid, "fila": start + len(batch_rows)},
            )
    finally:
        tokenizer.padding_side = previous_padding_side
    _notify_progress(
        progress_callback,
        status="finished",
        phase="validation generada",
        total=len(rows),
        completed=len(rows),
    )
    return scores, {
        "rows": len(rows),
        "valid_json_contract": valid,
        "schema_valid_rate": valid / max(1, len(rows)),
        "schema_errors": schema_errors,
        "max_new_tokens": max_new_tokens,
        "score_semantics": "self_reported_confidence_for_selected_labels_and_one_minus_for_others",
    }


def train_prompt_conditioned_sft(
    dataset_path: str | Path,
    prompt_path: str | Path,
    output_root: str | Path,
    *,
    device: str = "auto",
    safe_to_damage_ratio: float | None = 4.0,
    seed: int = 20260805,
    epochs: int = 2,
    max_length: int = 2560,
    train_limit: int | None = None,
    validation_limit: int | None = None,
    training_regime: str = "full",
    eligible_for_03_07: bool | None = None,
    max_training_seconds: float | None = None,
    max_total_seconds: float | None = None,
    generation_max_new_tokens: int = 192,
    prompt_capsule_max_chars: int = 6200,
    gradient_checkpointing: bool | None = None,
    run_label: str | None = None,
    force: bool = False,
    persistent_checkpoint_root: str | Path | None = None,
    progress_callback: ProgressCallback | None = None,
) -> dict[str, Any]:
    """LoRA SFT generativo condicionado por una cápsula trazable de v3.2."""

    safe_to_damage_ratio = _require_project_safe_ratio(safe_to_damage_ratio)
    if training_regime not in PROMPT_SFT_TRAINING_REGIMES:
        raise ValueError(
            "training_regime debe ser full, diagnostic_pilot o budgeted_comparable"
        )
    if (
        epochs <= 0
        or max_length < 512
        or generation_max_new_tokens < 32
        or prompt_capsule_max_chars < 3000
    ):
        raise ValueError("epochs, max_length o generation_max_new_tokens inválidos")
    if max_training_seconds is not None and max_training_seconds <= 0:
        raise ValueError("max_training_seconds debe ser positivo")
    if max_total_seconds is not None and max_total_seconds <= 0:
        raise ValueError("max_total_seconds debe ser positivo")
    if (
        max_training_seconds is not None
        and max_total_seconds is not None
        and max_training_seconds >= max_total_seconds
    ):
        raise ValueError("El presupuesto de entrenamiento debe dejar tiempo a validation")
    if eligible_for_03_07 is None:
        eligible_for_03_07 = training_regime in {"full", "budgeted_comparable"}
    if eligible_for_03_07 and validation_limit is not None:
        raise ValueError(
            "Un candidato elegible para 03_07 debe inferir validation completa"
        )
    if training_regime == "diagnostic_pilot" and eligible_for_03_07:
        raise ValueError("El piloto diagnóstico no puede entrar a 03_07")
    try:
        import torch
        from peft import LoraConfig, TaskType, get_peft_model
        from transformers import (
            AutoModelForCausalLM,
            AutoTokenizer,
            EarlyStoppingCallback,
            Trainer,
            TrainingArguments,
        )
    except ImportError as exc:
        raise RuntimeError("Instale moderacion-peru[entrenamiento]") from exc
    run_started = time.perf_counter()
    dataset = Path(dataset_path).resolve()
    prompt_path = Path(prompt_path).resolve()
    prompt_text = prompt_path.read_text(encoding="utf-8")
    prompt_sha = sha256_file(prompt_path)
    system_prompt = compile_operational_prompt_capsule(
        prompt_text, max_chars=prompt_capsule_max_chars
    )
    hardware = resolve_device(device)
    high_memory_profile = high_memory_bf16_cuda(hardware)
    budgeted = training_regime == "budgeted_comparable"
    train_batch_size = (
        4 if high_memory_profile and budgeted else (2 if high_memory_profile else 1)
    )
    eval_batch_size = 2 if high_memory_profile else 1
    gradient_accumulation = (
        2 if high_memory_profile and budgeted else (4 if high_memory_profile else 8)
    )
    dataloader_num_workers = 2 if high_memory_profile else 0
    generation_batch_size = (
        16 if high_memory_profile and budgeted else (4 if high_memory_profile else 1)
    )
    if gradient_checkpointing is None:
        gradient_checkpointing = not (budgeted and high_memory_profile)
    training_disclaimer = (
        "Candidato de presupuesto computacional limitado: se entrenó con un "
        "subconjunto determinista y/o menos épocas, pero se evaluó sobre la misma "
        "validation completa. No equivale al SFT exhaustivo ni permite atribuir "
        "su diferencia únicamente a la arquitectura."
        if budgeted
        else None
    )
    configuration = {
        "experiment": "qwen_prompt_sft",
        "model_id": PROMPT_SFT_MODEL_ID,
        "model_revision": PROMPT_SFT_MODEL_REVISION,
        "prompt_path": str(prompt_path),
        "prompt_sha256": prompt_sha,
        "prompt_capsule_sha256": __import__("hashlib")
        .sha256(system_prompt.encode())
        .hexdigest(),
        "safe_to_damage_ratio_train_validation": safe_to_damage_ratio,
        "test_policy": "full_natural_plus_4_to_1_secondary_same_predictions",
        "epochs": epochs,
        "max_length": max_length,
        "train_limit": train_limit,
        "validation_limit": validation_limit,
        "training_regime": training_regime,
        "eligible_for_03_07": bool(eligible_for_03_07),
        "max_training_seconds": max_training_seconds,
        "max_total_seconds": max_total_seconds,
        "generation_max_new_tokens": generation_max_new_tokens,
        "prompt_capsule_max_chars": prompt_capsule_max_chars,
        "run_label": run_label,
        "seed": seed,
        "performance_profile": cuda_performance_profile(hardware),
        "per_device_train_batch_size": train_batch_size,
        "per_device_eval_batch_size": eval_batch_size,
        "gradient_accumulation_steps": gradient_accumulation,
        "dataloader_num_workers": dataloader_num_workers,
        "generation_batch_size": generation_batch_size,
        "lora_gradient_checkpointing": (
            PROMPT_SFT_GRADIENT_CHECKPOINTING
            if gradient_checkpointing
            else "disabled_for_short_sequence_budget_profile"
        ),
        "test_status": "sealed_not_evaluated",
    }
    signature = _experiment_signature(dataset, "qwen_prompt_sft", configuration)
    run_dir = Path(output_root) / "runs" / f"qwen-prompt-sft-{signature[:16]}"
    persistent_checkpoint_dir = (
        Path(persistent_checkpoint_root) / run_dir.name / "trainer"
        if persistent_checkpoint_root is not None and not budgeted
        else None
    )
    diagnostic_pilot = training_regime == "diagnostic_pilot"
    candidate_path = run_dir / (
        "pilot_candidate.json" if diagnostic_pilot else "candidate.json"
    )
    if candidate_path.is_file() and not force:
        candidate = json.loads(candidate_path.read_text(encoding="utf-8"))
        if candidate.get("run_signature") == signature:
            candidate["candidate_path"] = str(candidate_path)
            _notify_progress(
                progress_callback,
                status="finished",
                phase="candidato ya existente",
                total=1,
                completed=1,
            )
            return {"status": "noop", "candidate": candidate}
    train, validation, test_sealed, sampling = _dataset_splits(
        dataset,
        split_scheme="video",
        safe_to_damage_ratio=safe_to_damage_ratio,
        sampling_seed=seed,
    )
    test_count = len(test_sealed)
    if train_limit is not None:
        train = sorted(
            train,
            key=lambda row: hashlib.sha256(
                f"{seed}|prompt-sft-train|{row['chunk_id']}".encode()
            ).hexdigest(),
        )[:train_limit]
    if validation_limit is not None:
        validation = sorted(
            validation,
            key=lambda row: hashlib.sha256(
                f"{seed}|prompt-sft-validation|{row['chunk_id']}".encode()
            ).hexdigest(),
        )[:validation_limit]
    torch_device = torch_device_name(hardware)
    tokenizer = AutoTokenizer.from_pretrained(
        PROMPT_SFT_MODEL_ID,
        revision=PROMPT_SFT_MODEL_REVISION,
        token=False,
    )
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token = tokenizer.eos_token
    model_kwargs: dict[str, Any] = {
        "revision": PROMPT_SFT_MODEL_REVISION,
        "token": False,
    }
    if hardware.dtype == "bfloat16":
        model_kwargs["dtype"] = torch.bfloat16
    elif hardware.dtype == "float16":
        model_kwargs["dtype"] = torch.float16
    if hardware.backend == "cuda":
        model_kwargs["attn_implementation"] = "sdpa"
    model = AutoModelForCausalLM.from_pretrained(PROMPT_SFT_MODEL_ID, **model_kwargs)
    model = get_peft_model(
        model,
        LoraConfig(
            task_type=TaskType.CAUSAL_LM,
            r=8,
            lora_alpha=16,
            lora_dropout=0.05,
            target_modules=["q_proj", "k_proj", "v_proj", "o_proj"],
        ),
    )
    model.config.use_cache = False
    gradient_diagnostics = _configure_lora_gradient_checkpointing(
        model, enabled=gradient_checkpointing
    )
    train_dataset = PromptCompletionDataset(
        tokenizer, train, system_prompt, max_length=max_length
    )
    validation_dataset = PromptCompletionDataset(
        tokenizer, validation, system_prompt, max_length=max_length
    )
    callbacks = []
    if not budgeted:
        callbacks.append(EarlyStoppingCallback(early_stopping_patience=1))
    if max_training_seconds is not None:
        from transformers import TrainerCallback

        class WallClockBudgetCallback(TrainerCallback):
            def __init__(self, seconds: float) -> None:
                self.seconds = seconds
                self.started_at: float | None = None

            def on_train_begin(self, args, state, control, **kwargs):
                self.started_at = time.perf_counter()
                return control

            def on_step_end(self, args, state, control, **kwargs):
                if (
                    self.started_at is not None
                    and time.perf_counter() - self.started_at >= self.seconds
                ):
                    control.should_training_stop = True
                    control.should_save = True
                return control

        callbacks.append(WallClockBudgetCallback(max_training_seconds))
    persistent_callback = build_persistent_checkpoint_callback(
        persistent_checkpoint_dir
    )
    if persistent_callback is not None:
        callbacks.append(persistent_callback)
    trainer = Trainer(
        model=model,
        args=TrainingArguments(
            output_dir=str(run_dir / "trainer"),
            num_train_epochs=epochs,
            per_device_train_batch_size=train_batch_size,
            per_device_eval_batch_size=eval_batch_size,
            gradient_accumulation_steps=gradient_accumulation,
            learning_rate=1e-4,
            eval_strategy="no" if budgeted else "epoch",
            save_strategy="epoch",
            load_best_model_at_end=not budgeted,
            metric_for_best_model=None if budgeted else "eval_loss",
            greater_is_better=None if budgeted else False,
            save_total_limit=2,
            report_to=[],
            seed=seed,
            use_cpu=hardware.backend == "cpu",
            bf16=hardware.dtype == "bfloat16",
            fp16=hardware.dtype == "float16",
            remove_unused_columns=False,
            dataloader_pin_memory=hardware.backend != "cpu",
            dataloader_num_workers=dataloader_num_workers,
            dataloader_persistent_workers=dataloader_num_workers > 0,
            dataloader_prefetch_factor=(2 if dataloader_num_workers > 0 else None),
            optim=(
                "adamw_torch_fused" if hardware.backend == "cuda" else "adamw_torch"
            ),
            tf32=high_memory_profile,
        ),
        train_dataset=train_dataset,
        eval_dataset=validation_dataset,
        callbacks=callbacks,
    )
    restored_checkpoint = restore_latest_trainer_checkpoint(
        persistent_checkpoint_dir, run_dir / "trainer"
    )
    checkpoint = str(restored_checkpoint) if restored_checkpoint is not None else None
    _notify_progress(
        progress_callback,
        status="started",
        phase="entrenamiento SFT (Trainer muestra pasos y épocas)",
        total=None,
        advance=0,
    )
    training_started = time.perf_counter()
    training_result = trainer.train(resume_from_checkpoint=checkpoint)
    training_elapsed = time.perf_counter() - training_started
    model.config.use_cache = True
    model.to(torch_device)
    validation_started = time.perf_counter()
    generation_deadline = (
        run_started + max_total_seconds if max_total_seconds is not None else None
    )
    validation_scores, generation = _generate_json_scores(
        model,
        tokenizer,
        validation,
        system_prompt,
        device=torch_device,
        max_input_length=max_length - generation_max_new_tokens,
        batch_size=generation_batch_size,
        max_new_tokens=generation_max_new_tokens,
        deadline_monotonic=generation_deadline,
        progress_callback=progress_callback,
    )
    validation_generation_elapsed = time.perf_counter() - validation_started
    taxonomy = load_taxonomy()
    output_labels = [
        *taxonomy.target_labels,
        *(f"fine:{label}" for label in taxonomy.fine_labels),
        *(f"flag:{flag}" for flag in taxonomy.flags),
    ]
    metrics_started = time.perf_counter()
    thresholds, validation_metrics, auxiliary = _evaluate_validation(
        run_dir, validation, validation_scores, output_labels
    )
    validation_metrics_elapsed = time.perf_counter() - metrics_started
    model_dir = run_dir / "adapter"
    model.save_pretrained(model_dir, safe_serialization=True)
    tokenizer.save_pretrained(model_dir)
    write_json_atomic(
        run_dir / "prompt_provenance.json", {**configuration, "capsule": system_prompt}
    )
    write_json_atomic(run_dir / "generation_quality.json", generation)
    inference = {
        "type": "hf_prompt_sft_json",
        "model": model_dir.name,
        "base_model": PROMPT_SFT_MODEL_ID,
        "base_revision": PROMPT_SFT_MODEL_REVISION,
        "prompt_sha256": prompt_sha,
        "prompt_capsule": "prompt_provenance.json",
        "max_input_length": max_length - generation_max_new_tokens,
        "max_new_tokens": generation_max_new_tokens,
        "batch_size": generation_batch_size,
    }
    bundle = run_dir / "inference.json"
    write_json_atomic(bundle, inference)
    manifest = _checkpoint_manifest(
        run_dir, [model_dir, bundle, run_dir / "prompt_provenance.json"]
    )
    candidate = {
        "schema_version": "4.0.0",
        "candidate_id": f"qwen-prompt-sft-{signature[:12]}",
        "experiment": "qwen_prompt_sft",
        "model_family": "qwen_prompt_sft",
        "training_regime": training_regime,
        "eligible_for_03_07": bool(eligible_for_03_07),
        "comparison_disclaimer": training_disclaimer,
        "training_budget": {
            "run_label": run_label,
            "train_limit": train_limit,
            "validation_limit": validation_limit,
            "epochs": epochs,
            "max_training_seconds": max_training_seconds,
            "max_total_seconds": max_total_seconds,
            "max_length": max_length,
            "generation_max_new_tokens": generation_max_new_tokens,
            "prompt_capsule_max_chars": prompt_capsule_max_chars,
            "validation_scope": (
                "full_common_validation"
                if validation_limit is None
                else "diagnostic_subset"
            ),
            "actual_train_rows": len(train),
            "actual_validation_rows": len(validation),
        },
        "conditioning": "operational_prompt_v3_2_capsule_plus_chunk_to_strict_json",
        "run_signature": signature,
        "dataset": str(dataset),
        "dataset_sha256": sha256_file(dataset),
        "target_labels": list(taxonomy.target_labels),
        "output_count": 22,
        "output_labels": output_labels,
        "thresholds": thresholds,
        "validation_metrics": validation_metrics,
        "auxiliary_validation_metrics": auxiliary,
        "test_metrics": None,
        "test_status": "sealed_not_evaluated",
        "generation_quality": generation,
        "training_sampling": {**sampling, "split_field": "split"},
        "metrics_path": "metrics.json",
        "checkpoint_manifest": manifest.name,
        "inference": {**inference, "bundle": bundle.name},
        "hardware": hardware.model_dump(),
        "training_metrics": dict(training_result.metrics),
        "gradient_diagnostics": gradient_diagnostics,
        "resumed_from_checkpoint": checkpoint,
        "persistent_checkpoint_dir": (
            str(persistent_checkpoint_dir)
            if persistent_checkpoint_dir is not None
            else None
        ),
        "stage_timings_seconds": {
            "training_fit": training_elapsed,
            "validation_generation": validation_generation_elapsed,
            "validation_metrics_and_thresholds": validation_metrics_elapsed,
            "total_before_candidate_write": time.perf_counter() - run_started,
        },
        "status": "pilot_complete" if diagnostic_pilot else "complete",
        "pilot_not_eligible_for_03_07": diagnostic_pilot,
        "completed_at": datetime.now(UTC).isoformat(),
        "engine": TRAINING_ENGINE_VERSION,
        "test_rows_sealed": test_count,
    }
    write_json_atomic(candidate_path, candidate)
    candidate["candidate_path"] = str(candidate_path)
    return {"status": "trained", "candidate": candidate}
